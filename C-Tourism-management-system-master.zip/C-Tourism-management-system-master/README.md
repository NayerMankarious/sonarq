## Tourism Management System
- This tourism management system application was created using C.
- The application can be used by customers as a full service for managing their travels from booking tickets to booking hotels.
- Customers can also generate bill.
- To see YouTube demonstration of this application [click here.](https://www.youtube.com/watch?v=RKRRbB4HdtA)

### Contributors:
<a href="https://github.com/ASHIK11ab">
  <img style="border-radius: 50px" src="https://avatars2.githubusercontent.com/u/58099865?s=460&u=dc835e2281a9265edf2b48059f1c8151be89a1b1&v=4" width="70px" height = "70px"> 
</a> 

[Ashik Meeran Mohideen](https://github.com/ASHIK11ab)

&copy; copyrights 2021. All rights reserved.

Licensed under [MIT LICENSE](https://github.com/ASHIK11ab/C-Tourism-management-system/blob/master/LICENSE)
